<?php
include 'db.php';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT);
    $ip = $_SERVER['REMOTE_ADDR'];
    
    // Validate username
    if (preg_match('/nigger/i', $username)) {
        die('Invalid username');
    }

    // Get a default avatar
    $avatarId = rand(1, 20); // Randomly assign an avatar from 1 to 20
    $avatarPath = "/avatars/$avatarId.png";

    // Check if the username already exists
    $checkQuery = "SELECT id FROM users WHERE username = ?";
    $stmt = $conn->prepare($checkQuery);
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        die('Username already exists');
    }
    
    $stmt->close();

    // Insert the new user
    $insertQuery = "INSERT INTO users (username, password, avatar) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($insertQuery);
    $stmt->bind_param("sss", $username, $password, $avatarPath);

    if ($stmt->execute()) {
        // Redirect to login page
        header('Location: index.html');
        exit();
    } else {
        echo 'Failed to register';
    }

    $stmt->close();
    $conn->close();
}
?>
