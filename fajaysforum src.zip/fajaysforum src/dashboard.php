<?php
session_start();
include 'db.php'; // Include your database connection

if (!isset($_SESSION['username'])) {
    header('Location: index.html');
    exit();
}

$username = isset($_SESSION['username']) ? htmlspecialchars($_SESSION['username']) : 'Guest';
$avatar = isset($_SESSION['avatar']) ? htmlspecialchars($_SESSION['avatar']) : 'default-avatar.png';

// Handle message submission
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['message'])) {
    $message = trim($_POST['message']);
    if (!empty($message)) {
        try {
            $stmt = $pdo->prepare("INSERT INTO chat_messages (username, message, timestamp) VALUES (?, ?, NOW())");
            $stmt->execute([$username, $message]);
        } catch (PDOException $e) {
            echo "Error: " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="dashboard.css">
    <link rel="icon" href="/assets/favicon.png" type="image/png">
</head>
<body>
    <div class="dashboard-container">
        <div class="header">
            <nav class="nav-bar">
                <a href="dashboard.php" class="nav-link">Home</a>
                <a href="avatars.php" class="nav-link">Avatars</a>
                <a href="settings.php" class="nav-link">Settings</a>
            </nav>
            <h1>Welcome, <?php echo $username; ?></h1>
        </div>
        <div class="main-content">
            <div class="avatar-box">
                <img src="/avatars/<?php echo $avatar; ?>" alt="User Avatar">
            </div>
            <div class="global-chat">
                <h2>Global Chat</h2>
                <div class="messages">
                    <?php
                    try {
                        $stmt = $pdo->query("SELECT username, message, timestamp FROM chat_messages ORDER BY timestamp DESC");
                        while ($row = $stmt->fetch()) {
                            echo '<div class="message">';
                            echo '<strong>' . htmlspecialchars($row['username']) . ':</strong> ' . htmlspecialchars($row['message']);
                            echo '<span class="timestamp">' . htmlspecialchars($row['timestamp']) . '</span>';
                            echo '</div>';
                        }
                    } catch (PDOException $e) {
                        echo "Error: " . $e->getMessage();
                    }
                    ?>
                </div>
                <form action="dashboard.php" method="post">
                    <textarea name="message" rows="4" placeholder="Type your message..."></textarea>
                    <button type="submit" class="submit-button">Send</button>
                </form>
            </div>
        </div>
    </div>
</body>
</html>
