document.addEventListener('DOMContentLoaded', () => {
    const dropdown = document.getElementById('avatar-dropdown');
    const selectedImage = document.getElementById('selected-image').querySelector('img');

    dropdown.addEventListener('change', (event) => {
        const selectedOption = event.target.options[event.target.selectedIndex];
        const imageUrl = selectedOption.getAttribute('data-image');
        selectedImage.src = imageUrl;
    });
});

    form.addEventListener('submit', function(event) {
        event.preventDefault();
        const message = messageInput.value.trim();

        if (message) {
            fetch('chat.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: new URLSearchParams({
                    'message': message,
                }),
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Append new message to chat
                    const messageElement = document.createElement('div');
                    messageElement.classList.add('message');

                    // Example of dynamic data for the logged-in user
                    const userAvatar = '/path/to/avatar.png'; // Update with real avatar path
                    const userName = 'Username'; // Update with real username

                    messageElement.innerHTML = `
                        <div class="message-header">
                            <img src="${userAvatar}" alt="User Avatar" class="message-avatar">
                            <span class="message-username">${userName}</span>
                            <span class="message-time">${new Date().toLocaleTimeString()}</span>
                        </div>
                        <div class="message-body">
                            ${message}
                        </div>
                    `;
                    messagesContainer.appendChild(messageElement);

                    // Clear the input field
                    messageInput.value = '';
                    messagesContainer.scrollTop = messagesContainer.scrollHeight;
                } else {
                    alert(data.message);
                }
            })
            .catch(error => console.error('Error:', error));
        }
    });
});
