<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Settings</title>
    <link rel="stylesheet" href="settings.css">
    <link rel="icon" href="/assets/favicon.png" type="image/png">
</head>
<body>
    <div class="settings-container">
        <div class="header">
            <h1>Settings</h1>
            <nav class="nav-bar">
                <a href="dashboard.php" class="nav-link">Home</a>
                <a href="avatars.php" class="nav-link">Avatars</a>
                <a href="settings.php" class="nav-link">Settings</a>
            </nav>
        </div>
        <div class="settings-content">
            <form action="update_settings.php" method="post">
                <div class="form-group">
                    <label for="username">Change Username:</label>
                    <input type="text" id="username" name="username" value="<?php echo htmlspecialchars($_SESSION['username']); ?>">
                </div>
                <div class="form-group">
                    <label for="password">Change Password:</label>
                    <input type="password" id="password" name="password">
                </div>
                <button type="submit" class="submit-button">Update Settings</button>
            </form>
        </div>
    </div>
</body>
</html>
