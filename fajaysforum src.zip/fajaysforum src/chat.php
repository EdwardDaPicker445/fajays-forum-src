<?php
include 'db.php';

session_start();

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'User not logged in']);
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $userId = $_SESSION['user_id'];
    $message = $_POST['message'];

    if (!empty($message)) {
        $query = "INSERT INTO chat_messages (user_id, message) VALUES (?, ?)";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("is", $userId, $message);

        if ($stmt->execute()) {
            echo json_encode(['success' => true, 'message' => 'Message sent']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Error: ' . $stmt->error]);
        }
    } else {
        echo json_encode(['success' => false, 'message' => 'Message cannot be empty']);
    }
}
?>
