<?php
$servername = 'mysql3.serv00.com';
$username = 'm5499_brickdata';
$password = '9i/WEetDo8MUsH-g6364a4^4BZl5P[';
$dbname = 'm5499_SupaBlox';

try {
    $pdo = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    // Set the PDO error mode to exception
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
}
?>
