<?php
session_start();
include 'db.php';

if (!isset($_SESSION['username'])) {
    header('Location: index.html'); // Redirect to login if not logged in
    exit();
}

$userId = $_SESSION['user_id'];
$newAvatarId = $_POST['avatar'];

// Validate the input
if (filter_var($newAvatarId, FILTER_VALIDATE_INT, array("options" => array("min_range" => 1, "max_range" => 20))) === false) {
    die('Invalid avatar selection');
}

// Update the avatar in the database
$updateQuery = "UPDATE users SET avatar = ? WHERE id = ?";
$newAvatarPath = "/avatars/" . $newAvatarId . ".png";
$stmt = $conn->prepare($updateQuery);
$stmt->bind_param("si", $newAvatarPath, $userId);

if ($stmt->execute()) {
    header('Location: dashboard.php'); // Redirect to dashboard after updating
} else {
    echo 'Failed to update avatar';
}

$stmt->close();
$conn->close();
?>
