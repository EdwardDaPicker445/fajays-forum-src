<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Avatars</title>
    <link rel="stylesheet" href="avatars.css">
    <link rel="icon" href="/assets/favicon.png" type="image/png">
</head>
<body>
    <div class="avatars-container">
        <div class="header-buttons">
            <a href="dashboard.php" class="dashboard-button">Dashboard</a>
        </div>
        <h1>Select an Avatar</h1>
        <form id="avatar-form" action="update_avatar.php" method="post">
            <div class="dropdown">
                <select id="avatar-dropdown" name="avatar">
                    <?php for ($i = 1; $i <= 20; $i++): ?>
                        <option value="<?php echo $i; ?>" data-image="/avatars/<?php echo $i; ?>.png">
                            Avatar <?php echo $i; ?>
                        </option>
                    <?php endfor; ?>
                </select>
                <div id="selected-image" class="selected-image">
                    <img src="/avatars/1.png" alt="Selected Avatar">
                </div>
            </div>
            <button type="submit" class="submit-button">Update Avatar</button>
        </form>
    </div>
    <script src="avatars.js"></script>
</body>
</html>
